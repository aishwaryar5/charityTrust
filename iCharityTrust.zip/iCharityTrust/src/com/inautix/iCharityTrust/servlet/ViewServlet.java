  package com.inautix.iCharityTrust.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.iCharityTrust.controller.SignupController;
import com.inautix.iCharityTrust.controller.UpdateController;
import com.inautix.iCharityTrust.controller.ViewProfileController;
import com.inautix.iCharityTrust.dao.SignupDao;
import com.inautix.iCharityTrust.domain.SignupDomain;
import com.inautix.iCharityTrust.domain.UpdateDomain;

/**
 * Servlet implementation class SignupServlet
 */
//@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
/*	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		HttpSession session = request.getSession();
        String userName=(String)session.getAttribute("userName");
        System.out.println("userName"+userName);

        ViewProfileController viewProfileController = new ViewProfileController();
      
        SignupDomain signupDomain= viewProfileController.viewController(userName);
     
	
	System.out.println("trustName:" +signupDomain.getUserName());
	System.out.println("trustPhoneNo:" +signupDomain.getPhoneNo());
	System.out.println("Address:" +signupDomain.getAddress());
	System.out.println("EmailId:" +signupDomain.getEmailId());
	System.out.println("trustpassword:" +signupDomain.getUserPassword());
	System.out.println("repeat:" +signupDomain.getRepeatPassword());
	
   
   session.setAttribute("signupDomain",signupDomain);
   RequestDispatcher rd = request.getRequestDispatcher("/ViewProfile.jsp");
   rd.forward(request, response);
   
	}
}
    
    