 package com.inautix.iCharityTrust.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.iCharityTrust.controller.SignupController;
import com.inautix.iCharityTrust.controller.UpdateController;
import com.inautix.iCharityTrust.dao.SignupDao;
import com.inautix.iCharityTrust.dao.UpdateUserDao;
import com.inautix.iCharityTrust.domain.SignupDomain;
import com.inautix.iCharityTrust.domain.UpdateDomain;

/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		String name1 = request.getParameter("userName");
		System.out.println("userName"+name1);
       String phoneNo1 = request.getParameter("phoneNo");
       System.out.println("phoneNo"+phoneNo1);
        String address1 = request.getParameter("address");
		System.out.println("address"+address1);
		String emailId1 = request.getParameter("emailId");
	     System.out.println("emailId"+emailId1);
		
        

       
        UpdateDomain updateDomain = new  UpdateDomain();
        updateDomain.setUserName(name1);
        updateDomain.setPhoneNo(phoneNo1);
        updateDomain.setAddress(address1);
        updateDomain.setEmailId( emailId1);
     

	//UpdateController updateController = new UpdateController();
	//updateController.updateController(updateDomain);
	
        UpdateUserDao updateDao = new UpdateUserDao();
		updateDao.updateUserDao(updateDomain);
	
 

  System.out.println("dao is called");
   
//   signupDao.createDao(signupDomain);
  HttpSession session = request.getSession(true);
   
   session.setAttribute("userName",updateDomain.getUserName() );
   RequestDispatcher rd = request.getRequestDispatcher("/WelcomeMember.jsp");
   rd.forward(request, response);
	}
}
    
    