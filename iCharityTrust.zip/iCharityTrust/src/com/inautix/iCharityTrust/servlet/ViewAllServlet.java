  package com.inautix.iCharityTrust.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.iCharityTrust.controller.SignupController;
import com.inautix.iCharityTrust.controller.UpdateController;
import com.inautix.iCharityTrust.controller.ViewAllController;
import com.inautix.iCharityTrust.controller.ViewProfileController;
import com.inautix.iCharityTrust.dao.SignupDao;
import com.inautix.iCharityTrust.domain.SignupDomain;

/**
 * Servlet implementation class SignupServlet
 */
//@WebServlet("/ViewAllServlet")
public class ViewAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAllServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
/*	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}*/

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
        ViewAllController viewAllController = new ViewAllController();
     
        List <SignupDomain> signupList= viewAllController.getAllView();
     
	
	
	//System.out.println("trustName:" +signupDomain.getTrustName());
	//System.out.println("trustPhoneNo:" +signupDomain.getPhoneNo());
	//System.out.println("Address:" +signupDomain.getAddress());
	//System.out.println("EmailId:" +signupDomain.getEmailId());
	//System.out.println("trustpassword:" +signupDomain.getPassword());
	//System.out.println("repeat:" +signupDomain.getRepeatPassword());
	
  // SignupDao signupDao = new SignupDao();
   System.out.println("dao is called");
//   signupDao.createDao(signupDomain);
   HttpSession session = request.getSession(true);
   session.setAttribute("signupDomainList",signupList);
   RequestDispatcher rd = request.getRequestDispatcher("/ViewAllProfile.jsp");
   rd.forward(request, response);
   
	}
}
    
    