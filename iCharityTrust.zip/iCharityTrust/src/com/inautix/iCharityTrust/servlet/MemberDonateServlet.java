package com.inautix.iCharityTrust.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.iCharityTrust.controller.MemberDonateController;
import com.inautix.iCharityTrust.controller.SignupController;
import com.inautix.iCharityTrust.controller.UpdateController;
import com.inautix.iCharityTrust.dao.SignupDao;
import com.inautix.iCharityTrust.domain.MemberDonateDomain;
import com.inautix.iCharityTrust.domain.SignupDomain;
import com.inautix.iCharityTrust.domain.UpdateDomain;

/**
 * Servlet implementation class SignupServlet
 */
//@WebServlet("/SignupServlet")
public class MemberDonateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberDonateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
		String donate = request.getParameter("donate");
		System.out.println("name"+donate);
		HttpSession session = request.getSession(true);
		String name=(String)session.getAttribute("name");  
        MemberDonateDomain memberDonateDomain = new  MemberDonateDomain();
        memberDonateDomain.setDonate(donate);
        long millis=System.currentTimeMillis();  
        java.sql.Date donatedDate=new java.sql.Date(millis);  
        System.out.println(donatedDate);          
        memberDonateDomain.setDonatedDate(donatedDate);
        memberDonateDomain.setUsername(name);
        //signupDomain.setAddress(address1);
        //signupDomain.setEmailId(emailId1);
        //signupDomain.setPassword(password1);
        //signupDomain.setRepeatPassword(repeatpassword1);

	MemberDonateController memberDonateController = new MemberDonateController();
	try {
		memberDonateController.memberDonateController(memberDonateDomain);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	System.out.println("name:" +memberDonateDomain.getDonate());
	System.out.println("date:" +memberDonateDomain.getDonatedDate());
	//System.out.println("Address:" +signupDomain.getAddress());
	//System.out.println("EmailId:" +signupDomain.getEmailId());
	//System.out.println("userPassword:" +signupDomain.getPassword());
	//System.out.println("repeat:" +signupDomain.getRepeatPassword());
	
  // SignupDao signupDao = new SignupDao();
   System.out.println("dao is called");
//   signupDao.createDao(signupDomain);
   
   session.setAttribute("trustname",memberDonateDomain.getDonate() );
   RequestDispatcher rd = request.getRequestDispatcher("/WelcomeMember.jsp");
   rd.forward(request, response);
	}
}
    
    