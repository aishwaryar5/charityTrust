 package com.inautix.iCharityTrust.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.inautix.iCharityTrust.dao.LoginDao;
import com.inautix.iCharityTrust.domain.LoginDomain;

/**
 * Servlet implementation class SigninServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public LoginServlet(){
		
		super();
	}
       
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 * 
	 */
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method
		
		System.out.println("inside LoginSevlet doPost method");
		String userName1 = request.getParameter("userName");
		String emailId1 = request.getParameter("emailId");
		String Password1 =request.getParameter("userPassword");
		
		
		LoginDomain loginDomain = new LoginDomain();
		loginDomain.setUserName(userName1);
		loginDomain.setEmailId(emailId1);
		loginDomain.setUserPassword(Password1);
		System.out.println("userName: "+userName1);
		System.out.println("emailId: "+emailId1);
		System.out.println("password:"+Password1);
		LoginDao loginDao=new LoginDao();
	
		
		boolean authenticate = false;
		try {
			authenticate = loginDao.authenticateUser(loginDomain);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(authenticate){
			HttpSession session=request.getSession(true);
			session.setAttribute("name", loginDomain.getUserName());
			
			System.out.println("inside siginservlet authentiction passed "+loginDomain.getUserName());
			RequestDispatcher rd = request.getRequestDispatcher("/HomePage.html");
			rd.forward(request, response);
			
		}else 
		{
			request.setAttribute("key", "Login failed");
			RequestDispatcher rd = request.getRequestDispatcher("/Login.jsp");
			rd.forward(request, response);
		}
	}
}
			
		
		
		