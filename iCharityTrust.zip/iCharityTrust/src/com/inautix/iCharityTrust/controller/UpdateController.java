package com.inautix.iCharityTrust.controller;


import com.inautix.iCharityTrust.dao.UpdateUserDao;

import com.inautix.iCharityTrust.domain.UpdateDomain;

public class UpdateController {
	
	public void  updateController( UpdateDomain updateDomain){
		
		UpdateUserDao updateDao = new UpdateUserDao();
		updateDao.updateUserDao(updateDomain );
	}

}