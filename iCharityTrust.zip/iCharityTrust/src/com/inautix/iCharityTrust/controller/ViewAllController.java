package com.inautix.iCharityTrust.controller;

import java.util.List;
import com.inautix.iCharityTrust.dao.ViewAllDao;
import com.inautix.iCharityTrust.domain.SignupDomain;

public class ViewAllController {
	public List<SignupDomain> getAllView(){
		ViewAllDao viewAllDao = new ViewAllDao();
		List<SignupDomain> SignupDomainList = null;
		SignupDomainList = viewAllDao.getAllSignupDetails();
		return SignupDomainList;
	}
	
	
		}