package com.inautix.iCharityTrust.controller;

import com.inautix.iCharityTrust.dao.ViewProfileDao;
import com.inautix.iCharityTrust.domain.SignupDomain;

public class ViewProfileController {
	  	
	  public SignupDomain viewController(String userName){
	  			
	  			ViewProfileDao viewDao = new ViewProfileDao();
	  			System.out.println(viewDao);
	  			SignupDomain signupDomain= viewDao.viewProfileDao(userName);
	  			System.out.println(signupDomain);
	  			return signupDomain;
	  				}
	  		
	  		
	  	}