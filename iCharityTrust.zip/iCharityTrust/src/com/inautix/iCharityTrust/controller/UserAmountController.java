package com.inautix.iCharityTrust.controller;

import com.inautix.iCharityTrust.dao.UserAmountDao;

import com.inautix.iCharityTrust.domain.UserAmountDomain;

public class UserAmountController {
	 public UserAmountDomain AmountController(String userName){
			
			UserAmountDao userAmountDao = new UserAmountDao();
			System.out.println(userAmountDao);
			UserAmountDomain userAmountDomain= userAmountDao.AmountDao(userName);
			System.out.println(userAmountDomain);
			return userAmountDomain;
				}
		

}
