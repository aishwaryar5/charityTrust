package com.inautix.iCharityTrust.controller;



import com.inautix.iCharityTrust.dao.LoginDao;
import com.inautix.iCharityTrust.domain.LoginDomain;

public class LoginController {
	
	public boolean  validateController( LoginDomain loginDomain) throws Exception{
		
		LoginDao loginDao=new LoginDao();
		boolean status = false;
		try {
			status = loginDao.authenticateUser(loginDomain);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		return status;
		
	}

}