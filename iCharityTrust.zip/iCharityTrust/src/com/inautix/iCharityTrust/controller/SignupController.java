package com.inautix.iCharityTrust.controller;

import com.inautix.iCharityTrust.dao.SignupDao;
import com.inautix.iCharityTrust.domain.SignupDomain;

public class SignupController {
	
	public void  createController( SignupDomain signupDomain) throws Exception{
		System.out.println("controller is called");
		SignupDao signupDao = new SignupDao();
		signupDao.createDao( signupDomain);
	}

}
