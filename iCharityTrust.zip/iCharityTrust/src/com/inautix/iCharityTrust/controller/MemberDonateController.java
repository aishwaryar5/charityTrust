package com.inautix.iCharityTrust.controller;


import com.inautix.iCharityTrust.dao.MemberDonateUserDao;
import com.inautix.iCharityTrust.domain.MemberDonateDomain;


public class MemberDonateController {
	
	public void  memberDonateController( MemberDonateDomain memberDonateDomain) throws Exception{
		
		MemberDonateUserDao memberDonateDao = new MemberDonateUserDao();
		memberDonateDao.memberDonateUserDao(memberDonateDomain );
	}

}
