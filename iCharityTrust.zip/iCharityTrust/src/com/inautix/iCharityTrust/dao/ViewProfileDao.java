package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.SignupDomain;

public class ViewProfileDao {
	Connection con = null;
	SignupDomain signupDomain = null;

	public SignupDomain viewProfileDao(String userName) {
		System.out.println("userName" + userName);
		Connection con = null;

		SignupDomain signupDomain = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana",
					"shobana");

			Statement stmt = con.createStatement();
			String sql = "select * from register_xbbnhgc where userName ='"+ userName + "'";
			System.out.println("SQL " + sql);
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				signupDomain = new SignupDomain();
				System.out.println("inside while loop");
				signupDomain.setUserName(rs.getString("userName"));
				signupDomain.setPhoneNo(rs.getString("phoneno"));
				signupDomain.setAddress(rs.getString("address"));
				signupDomain.setEmailId(rs.getString("emailId"));

			}

		} catch (Exception e) {

		} finally {
			try {

				con.close();
			} catch (Exception e) {

			}
		}

		return signupDomain;
	}
}
