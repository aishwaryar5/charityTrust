package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.UpdateAdminDomain;
import com.inautix.iCharityTrust.domain.UpdateDomain;
import com.inautix.iCharityTrust.domain.UserAmountDomain;

public class UpdateAdminDao {
	public void updateAdminDao(UpdateAdminDomain updateAdminDomain) {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {

			System.out.println(e);

		}
		try {

			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();

			String sql = "update donate_xbbnhgc set userMoney='"+ updateAdminDomain.getUserMoney() +"' where userName='"+ updateAdminDomain.getUserName() + "'";
		
			System.out.println("sql "+sql);                                        
			
			
			stmt.execute(sql);
			
			    
			System.out
					.println(" Record has been updated successfully");
			con.commit();
			con.close();
		} catch (Exception e) {

			System.out.println("Exception:" + e);

		} finally {
			try {
				con.close();

			} catch (Exception e) {

			}
		}

	}
}
