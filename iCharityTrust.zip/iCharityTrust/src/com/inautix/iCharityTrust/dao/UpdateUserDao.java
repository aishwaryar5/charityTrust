package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.UpdateDomain;

public class UpdateUserDao {

	public void updateUserDao(UpdateDomain updateDomain) {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {

			System.out.println(e);

		}
		try {

			con = DriverManager.getConnection("jdbc:oracle:thin:@10.232.71.29:1521:INATP02","shobana","shobana");

			Statement stmt = con.createStatement();

			String sql = "update register_xbbnhgc set phoneNo='"+ updateDomain.getPhoneNo() +"' where userName='"+ updateDomain.getUserName() + "'";
			String sql2 ="update register_xbbnhgc set address ='"+updateDomain.getAddress() +"'  where userName='"+updateDomain.getUserName() + "'";
			String sql3 ="update register_xbbnhgc set emailId ='"+updateDomain.getEmailId() +"'  where userName='"+updateDomain.getUserName() + "'";
			System.out.println("sql "+sql);                                        
			
			System.out.println("sql "+sql2);
			System.out.println("sql "+sql3);
			stmt.execute(sql);
			stmt.execute(sql2);
			stmt.execute(sql3);
			    
			System.out
					.println(" Record has been updated successfully");
			con.commit();
			con.close();
		} catch (Exception e) {

			System.out.println("Exception:" + e);

		} finally {
			try {
				con.close();

			} catch (Exception e) {

			}
		}

	}
}
