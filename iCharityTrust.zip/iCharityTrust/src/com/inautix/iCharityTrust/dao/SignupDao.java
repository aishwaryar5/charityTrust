package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.SignupDomain;

public class SignupDao {

	public void createDao(SignupDomain signupDomain)throws Exception {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana",
					"shobana");

			Statement stmt = con.createStatement();
			String sql = "insert into register_xbbnhgc values (" + "'"
					+ signupDomain.getUserName() + "','"
					+ signupDomain.getPhoneNo() + "','"
					+ signupDomain.getAddress() + "','"
					+ signupDomain.getEmailId() + "','"
					+ signupDomain.getUserPassword() + "','"
					+ signupDomain.getRepeatPassword() + "')";
			System.out.println("sql" + sql);
			stmt.execute(sql);

			con.commit();
			con.close();
			System.out.println(" record inserted successfully");
		} catch (Exception e) {
			System.out.println("exception :" + e);

		} finally {
			try {

				con.close();
			} catch (Exception e) {

			}

		}

	}

}
