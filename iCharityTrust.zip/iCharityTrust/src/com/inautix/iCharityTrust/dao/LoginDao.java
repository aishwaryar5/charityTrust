package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.LoginDomain;

public class LoginDao {

	public boolean authenticateUser(LoginDomain loginDomain) throws Exception {
		System.out.println("inside authenticateUser method");
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		String password = null;
		try {
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana",
					"shobana");

			Statement stmt = con.createStatement();

			String sql = "select userPassword from register_xbbnhgc where userName='"+loginDomain.getUserName()+ "'";
			System.out.println("sql" + sql);
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				
				password=rs.getString("userPassword");
			}
			
		}catch(Exception e){
			
			System.out.println("exception occured 2 "+e);
		}
		
		
		boolean authenticate = false;
		if(loginDomain.getUserPassword().equals(password)){
			authenticate=true;
			
		}
		return authenticate;
		
		
		
		
		
		
	}
	
	
}


