package com.inautix.iCharityTrust.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.UserAmountDomain;

public class UserAmountDao {
  Connection con = null;
  UserAmountDomain userAmountDomain = null;

	public  UserAmountDomain  AmountDao(String userName) {
		System.out.println("userName" + userName);
		Connection con = null;

	
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana",
					"shobana");

			Statement stmt = con.createStatement();
			String sql = "select c.userName ,o.usermoney from donate_xbbnhgc o inner join register_xbbnhgc c on  c.userName=o.userName";
			System.out.println("SQL " + sql);
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				userAmountDomain = new UserAmountDomain();
				System.out.println("inside while loop");
				userAmountDomain.setUserName(rs.getString("userName"));
				userAmountDomain.setUserMoney(rs.getString("userMoney"));
			

			}

		} catch (Exception e) {

		} finally {
			try {

				con.close();
			} catch (Exception e) {

			}
		}

		return userAmountDomain;
	}
}
