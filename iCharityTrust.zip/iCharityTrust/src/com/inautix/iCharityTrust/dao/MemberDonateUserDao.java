package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import com.inautix.iCharityTrust.domain.MemberDonateDomain;

public class MemberDonateUserDao {

	public void memberDonateUserDao(MemberDonateDomain memberDonateDomain) throws Exception {
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {

			System.out.println(e);

		}
		try {

			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29.1521:INATPO2", "shobana",
					"shobana");

			Statement stmt = con.createStatement();
			// String sql = "insert into Signup_xbbnhgc values (" +"'"
			// +signupDomain.getTrustName() +"','" +signupDomain.getPhoneNo()
			// +",'" +signupDomain.getAddress() +"','"
			// +signupDomain.getEmailId() +"','" +signupDomain.getPassword()
			// +"','" +signupDomain.getRepeatPassword() +"')";
			String sql = "insert into donate values(" + "'"
					+ memberDonateDomain.getDonate() + "','"
					+ memberDonateDomain.getDonatedDate() + "')";
			System.out.println("sql" + sql);
			stmt.execute(sql);
			con.commit();
			con.close();

			System.out
					.println("Member Donate Record has been inserted successfully");
		} catch (Exception e) {

			System.out.println("Exception:" + e);

		} finally {
			try {
				con.close();

			} catch (Exception e) {

			}
		}

	}
}
