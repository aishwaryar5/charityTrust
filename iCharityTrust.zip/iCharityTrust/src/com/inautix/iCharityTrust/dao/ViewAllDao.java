package com.inautix.iCharityTrust.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.inautix.iCharityTrust.domain.SignupDomain;

public class ViewAllDao {
	public List<SignupDomain> getAllSignupDetails() {
		Connection con = null;

		List<SignupDomain> signupDomainList = new ArrayList<SignupDomain>();

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		}

		try {
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.232.71.29:1521:INATP02", "shobana",
					"shobana");

			Statement stmt = con.createStatement();

			String sql = "select * from register_xbbnhgc";
			System.out.println("SQL " + sql);
			ResultSet rs = stmt.executeQuery(sql);

			SignupDomain signupDomain = null;
			while (rs.next()) {
				signupDomain = new SignupDomain();
				signupDomain.setUserName(rs.getString("userName"));
				signupDomain.setPhoneNo(rs.getString("phoneNo"));
				signupDomain.setAddress(rs.getString("address"));
				signupDomain.setEmailId(rs.getString("emailId"));

				System.out.println(rs.getString("userName"));
				signupDomainList.add(signupDomain);
			}

		} catch (Exception e) {

		} finally {
			try {

				con.close();
			} catch (Exception e) {

			}
		}
		System.out.println("no of elements in dao" + signupDomainList.size());
		return signupDomainList;

	}
}
