package com.inautix.iCharityTrust.domain;

import java.sql.Date;

public class MemberDonateDomain {
    String donate;
	Date donatedDate;
	String username;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDonate() {
		return donate;
	}
	public void setDonate(String donate) {
		this.donate = donate;
	}
	public Date getDonatedDate() {
		return donatedDate;
	}
	public void setDonatedDate(Date donatedDate) {
		this.donatedDate = donatedDate;
	}
	
		
}
