package com.inautix.iCharityTrust.domain;

public class UpdateAdminDomain {
	String userName;
	String userMoney;
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserMoney() {
		return userMoney;
	}
	public void setUserMoney(String userMoney) {
		this.userMoney = userMoney;
	}
}
