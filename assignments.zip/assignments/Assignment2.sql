select city,address,branch_code from BRANCH_XBBNHGC where Branch_code NOT IN(select branch_code from EMP_XBBNHGC where desig='programmer');
select emp_code,emp_name,address,city,pincode,phone from EMP_XBBNHGC
where emp_code in (select boss from EMP_XBBNHGC where desig='manager' and branch_code in
(select branch_code from BRANCH_XBBNHGC where city='coimbatore' or city='Coimbatore'));
select emp_code,emp_name,address,city,pincode from EMP_XBBNHGC
where emp_code in (select representative from CUST_XBBNHGC
where name='TVS');
select cust_code,name from CUST_XBBNHGC where REPRESENTATIVE IN (select emp_code from EMP_XBBNHGC
               where desig='representative'and branch_code IN
               (select branch_code from BRANCH_XBBNHGC where city='Coimbatore'or city='coimbatore'));
Select emp_code,emp_name from EMP_XBBNHGC where emp_code in(select representative from CUST_XBBNHGC where city= �MADURAI� );
select * from ORDER_XBBNHGC where CUSTOMER_ID IN(select CUST_CODE from CUST_XBBNHGC where CREDIT_LIMIT between 50000 and 70000);
Select * from EMP_XBBNHGC where branch_code=(select branch_code from EMP_XBBNHGC where emp_name=�GOKUL�);
select ITEM_ID,ITEM_NAME from ITEM_XBBNHGC where ITEM_ID IN(select ITEM_ID from Sales85 where QUANTITY>=10);
select EMP_CODE,EMP_NAME,salary from EMP_XBBNHGC
               where salary>(select salary from EMP_XBBNHGC
where EMP_NAME='HARI');
select EMP_CODE,EMP_NAME from EMP_XBBNHGC
where EMP_CODE NOT IN(select EMP_CODE from EMP_XBBNHGC where EMP_CODE IN
(select BOSS from EMP_XBBNHGC));
select NAME from CUST_XBBNHGC where CREDIT_LIMIT>75000 and REPRESENTATIVE in
   (select EMP_CODE from EMP_XBBNHGC where BRANCH_CODE in     
  (select BRANCH_CODE from BRANCH_XBBNHGC where CITY='Madurai'));
drop table register_xbbnhgc;
select * from register_xbbnhgc;

create table register_xbbnhgc(
                  
                trustName   varchar(100)   not null Unique,
                phoneNo       varchar(100) not null,
                address    varchar(100) not null,
                emailId    varchar(50) unique not null ,
                trustPassword varchar(38) not null);
                
insert into register_xbbnhgc(trustName,phoneNo,address,emailId,trustPassword)  values ('SahithyaTrust' ,'24867512','Vadapalani,chennai','sathithya@gmail.com','st');                