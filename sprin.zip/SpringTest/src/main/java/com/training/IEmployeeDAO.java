package com.training;
import java.sql.ResultSet;





import javax.sql.DataSource;

import org.springframework.jdbc.core.ResultSetExtractor;  

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public interface IEmployeeDAO {
	
	
	public void createEmployee(Employee employee);
	public void createEmployee1(Employee employee);
	public List<Employee> retrieveEmployee(int dept_ID);
	
	
		
		
	}



