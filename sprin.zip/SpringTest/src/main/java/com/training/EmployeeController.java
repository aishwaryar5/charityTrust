package com.training;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
@RestController

public class EmployeeController {
	   @Autowired
		EmployeeDAO employeeDAO;
		  @RequestMapping(value="employees/{dept_ID}", method = RequestMethod.GET)
		    public List retrieveEmployee(@PathVariable("dept_ID") int dept_ID){
		    	List<Employee> employeeList = employeeDAO.retrieveEmployee(dept_ID);
		    	System.out.println(dept_ID);
				if(employeeList==null)
				{
					Employee employee =new Employee();
					 employee.setEmp_ID(0);
					 employee.setEmp_Name(null);
					 employee.setDob(null);
					 employee.setDesignation(null);
					 employee.setDept_ID(0);
					 employee.setDept_Name(null);
				
				}
					
				else
				{
					
				}
					
		      return employeeList;
		    }
		  
		  
 @RequestMapping(value="/employees", method = RequestMethod.POST)
public String createEmployee(@RequestBody Employee employee){
	employeeDAO.createEmployee(employee);
  return "A New record is created successfully";
}

 
@RequestMapping(value="/employees1", method = RequestMethod.POST)
public String createEmployee1(@RequestBody Employee employee){
employeeDAO.createEmployee(employee);
return "A New record is created successfully";
}


}

