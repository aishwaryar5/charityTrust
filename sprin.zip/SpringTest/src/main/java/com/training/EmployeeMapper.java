package com.training;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

public class EmployeeMapper implements ResultSetExtractor<Object> {

	public Object extractData(ResultSet arg0) throws SQLException,
			DataAccessException {
		// TODO Auto-generated method stub
		return null;
	}


		public Employee mapRow(ResultSet rs, int rowNum) throws SQLException {
			Employee employee= new Employee();
			employee.setEmp_ID(rs.getInt("emp_ID"));
			employee.setEmp_Name(rs.getString("emp_Name"));
			employee.setDob(rs.getString("dob"));
			employee.setDesignation(rs.getString("designation"));
			employee.setDept_ID(rs.getInt("dept_ID"));
			employee.setDept_Name(rs.getString("dept_Name"));
		      return employee;
		   }
		
	}


