package com.training;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;


public class EmployeeDAO {
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	  
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }


		public void createEmployee(Employee employee) {
			jdbcTemplateObject.update("insert into EMPLOYEE1_xbbnhgc values("+employee.getEmp_ID()+",'"+employee.getEmp_Name()+"',"+employee.getDob() +",'"+employee.getDesignation() +"',"+employee.getDept_ID()  +")");
		}



	public void createEmployee1(Employee employee) {
		jdbcTemplateObject.update("insert into   DEPARTMENT1_xbbnhgc values("+employee.getDept_ID() +",'"+employee.dept_Name+"'," +")");
	}
	

	//to view including the department name

	@SuppressWarnings("unchecked")
	public List<Employee> retrieveEmployee(int dept_ID) {
		// TODO Auto-generated method stub
         List<Employee> employee1=null;
		   try
		   {
		      String SQL = "select  o.EMP_ID,o.EMP_NAME,o.DOB, c.dept_name,o.DESIGNATION,o.DEPT_ID from EMPLOYEE1_xbbnhgc o inner join DEPARTMENT1_xbbnhgc  c on c.dept_id=o.DEPT_ID";
		      employee1 = (List<Employee>) jdbcTemplateObject.query(SQL, new Object[]{}, new EmployeeMapper());
		      
		   }
		   catch(Exception e)
		   {
			   e.printStackTrace();
		   }
		   return employee1;
	   }
}
	
	
	
	

