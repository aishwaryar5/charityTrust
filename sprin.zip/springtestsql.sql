
COMMIT;
insert into DEPARTMENT1_xbbnhgc (DEPT_ID ,dept_name)  values (12,'developer');  
insert into EMPLOYEE1_xbbnhgc(EMP_ID,EMP_NAME,DOB,DESIGNATION,DEPT_ID)  values (3,'c', '03-APR-95','mngr',12);  
create table EMPLOYEE1_xbbnhgc( EMP_ID number(10) primary key,  EMP_NAME VARCHAR(20), DOB varchar(10) , DESIGNATION VARCHAR(20), DEPT_ID NUMBER(10));
  drop table EMPLOYEE1_xbbnhgc;             
        create table DEPARTMENT1_xbbnhgc ( dept_id number(20) primary key , dept_name  varchar(20));       
                 select * from  DEPARTMENT1_xbbnhgc; 
                select * from employee1_xbbnhgc;
                select  o.EMP_ID,o.EMP_NAME,o.DOB, c.dept_name,o.DESIGNATION,o.DEPT_ID from EMPLOYEE1_xbbnhgc o inner join DEPARTMENT1_xbbnhgc  c on c.dept_id=o.DEPT_ID;
                
              