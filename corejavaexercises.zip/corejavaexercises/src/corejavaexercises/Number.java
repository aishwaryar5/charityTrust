package corejavaexercises;

class Number
{
int fno,sno,tno,sum;
Number(int f,int s,int t)
{
fno=f;
sno=s;
tno=t;
}
void cons()
{
sum=fno+tno+sno;
System.out.print(sum);
}
}
