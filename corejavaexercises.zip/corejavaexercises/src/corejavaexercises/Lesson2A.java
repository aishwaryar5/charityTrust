package corejavaexercises;


public class Lesson2A {
		
	
	public static void main(String arg[])
	{
	int a=10,b=12;
	float f=12.5f;
	String s="Java Programming";
	System.out.println(a);
	System.out.println(b);
	System.out.println(f);
	System.out.println(s);
	}
	}


