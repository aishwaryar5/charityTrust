package corejavaexercises;
import java.util.*;
public class Xbbnhbq_Sort {
	
	public static void main(String as[])
	{
	  Scanner s=new Scanner(System.in);
	System.out.println("Enter no.of elements");
	  int n=s.nextInt();
	  int[] a=new int[n];
	System.out.println("Enter elements:");
	  for(int i=0;i<n;i++)
	   a[i]=s.nextInt();
	int temp;
	for(int i=0;i<n;i++)
	{
	  for(int j=i+1;j<n;j++)
	{
	   if(a[i]>a[j])
	{
	   temp=a[i];
	a[i]=a[j];
	a[j]=temp;
	s.close();
	}
	}
	}
	System.out.println("Sorted Elements in ascending order:");
	for(int i=0;i<n;i++)
	System.out.println(a[i]);
	System.out.println("Sorted Elements in descending order:");
	for(int i=n-1;i>=0;i--)
	System.out.println(a[i]);
	}
	}

