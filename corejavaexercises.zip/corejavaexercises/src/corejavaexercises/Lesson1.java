package corejavaexercises;

public class Lesson1 {
	
	
	public static void main  (String args[]){
	
	       System.out.println("Hello "+args[0]);



}
}
