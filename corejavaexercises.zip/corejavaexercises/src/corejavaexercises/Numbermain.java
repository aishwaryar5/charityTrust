package corejavaexercises;

public class Numbermain {


public static void main(String arg[])
{
Number n=new Number(10,20,30);
n.cons();
}
}
