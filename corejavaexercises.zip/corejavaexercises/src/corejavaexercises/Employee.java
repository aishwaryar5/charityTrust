package corejavaexercises;


import java.util.*;
class Employee
{
int empno,salary,sal=0;
String name,desig;
Scanner sc=new Scanner(System.in);
void getDetails()
{
System.out.println("Enter details");
empno=sc.nextInt();
name=sc.next();
desig=sc.next();
salary=sc.nextInt();
}
void putDetails()
{
System.out.println("Empno= "+empno);
System.out.println("Name= "+name);
System.out.println("Desig= "+desig);
System.out.println("Salary= "+salary);

 sal = sal+ salary;
System.out.println("Total salary= "+sal);
}
public class Emp
{
public void main (String arg[])
{
Employee e;
e=new Employee();
e.getDetails();
e.putDetails();

e.getDetails();
e.putDetails();
}
}
}

