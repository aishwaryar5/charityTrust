package corejavaexercises;

public class Lesson2E{
	
	public static void main(String s[])
	{
	int a;
	a=Integer.parseInt(s[0]);
	if(a>=18)
	{	
	System.out.println("Eligible to vote");
	}else
	{
	System.out.println("Not Eligible");
	}
	}
	}



