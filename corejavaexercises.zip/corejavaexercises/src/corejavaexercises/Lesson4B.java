package corejavaexercises;


class Xbbnhbq_Sum
{
public static void main(String as[])
{
   int a=5,b=9,sum;
    sum=a+b;
   System.out.println("Sum:"+sum);
}
}

