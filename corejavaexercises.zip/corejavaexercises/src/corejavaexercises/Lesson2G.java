package corejavaexercises;

public class Lesson2G {
	
	
	public static void main(String s[])
	{
	int a;
	a=Integer.parseInt(s[0]);
	if(a>=50)
	{
	System.out.println("PASS");
	}
	else
	{
	System.out.println("FAIL");
	}
	}
	}


