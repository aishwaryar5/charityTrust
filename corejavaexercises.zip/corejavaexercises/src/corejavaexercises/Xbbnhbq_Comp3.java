package corejavaexercises;
import java.util.*;
public class Xbbnhbq_Comp3 {

	public static void main(String as[])
	{
	   Scanner s=new Scanner(System.in);
	     System.out.println("Enter 3 elements to compare:");
	   int a=s.nextInt();
	int b=s.nextInt();
	int c=s.nextInt();
	s.close();
	  if((a==b)&&(b==c))
	   System.out.println("All are equal");
	  else if((a>b)&&(a>c))
	   System.out.println(a+" is greater than "+b+" and "+c);
	   else if(b>c)
	  System.out.println(b+" is greater than "+a+" and "+c);
	  else
	System.out.println(c+" is greater than "+a+" and "+b);

	}
	}

