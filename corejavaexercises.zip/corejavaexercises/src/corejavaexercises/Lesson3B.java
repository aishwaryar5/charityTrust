package corejavaexercises;

public class Lesson3B{
	int width,height,depth;
	Lesson3B(int w,int h,int d)
	  {
	   width=w;
	   height=h;
	   depth=d;
	  }

	 public static void main(String arg[])
	  {
	   //Box b=new Box();
		 Lesson3B b =new Lesson3B(1,2,3);
	   System.out.println("Width= " +b.width);
	   System.out.println("Height= " +b.height);
	   System.out.println("Depth= " +b.depth);
	  }
	}


