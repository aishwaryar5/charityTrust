package corejavaexercises;
import java.util.*;
public class Lesson4D {

public static void main(String as[])
{
   int n,sum=0;
System.out.println("Enter no.of elements:");
   Scanner s=new Scanner(System.in);
     n=s.nextInt();
     s.close();
    int[] a=new int[n];
System.out.println("Enter elements:");
for(int i=0;i<n;i++)
{
    a[i]=s.nextInt();
    sum+=a[i];
}
   System.out.println("Sum:"+sum);
}
}

