package corejavaexercises;

import java.util.*;

public class Lesson2B {
	public static void main(String args[])
	{
	int a,b,c,d,e;
	float f;
	Scanner sc = new Scanner(System.in);
	System.out.print("Enter numbers");
	a=sc.nextInt();
	b=sc.nextInt();
	sc.close();

	c=a+b;
	e=a*b;
	if(a>b)
	{
	d=a-b;
	}
	else
	{
	d=b-a;
	}
	if(a>b)
	{
	f=a/b;
	}
	else
	{
	f=b/a;
	}
	System.out.print(c+ " " +d+" "+e+" "+f);
	}
		}


