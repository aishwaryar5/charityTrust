package corejavaexercises;
 class Lesson4A {



public static void main(String as[])
{
   System.out.println("Hello World");
}
}
