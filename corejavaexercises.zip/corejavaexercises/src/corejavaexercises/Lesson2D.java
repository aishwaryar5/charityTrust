package corejavaexercises;
public class Lesson2D {
		

	public static void main(String s[]){
	int a;
	float b,c,si,amt,intr;
	a=Integer.parseInt(s[0]);
	b=Float.parseFloat(s[1]);
	c=Float.parseFloat(s[2]);
	si=((a*b)/100);
	amt=((si*c)/100);
	intr=si-amt;
	System.out.println(intr);
	}
	}


