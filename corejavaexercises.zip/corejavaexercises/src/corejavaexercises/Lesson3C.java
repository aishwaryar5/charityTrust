package corejavaexercises;
class Lesson {
	
	
	 int width,height,depth;
	 Lesson (int w,int h,int d)
	  {
	   width=w;
	   height=h;
	   depth=d;
	  }
	  public int volume()
	  {
	   int volume;
	   volume= width*height*depth;
	   return volume;
	  }
	}
	class Lesson3C
	{
	 public static void main(String arg[])
	  {
	   //Box b=new Box();
		 Lesson b=new Lesson(1,2,3);
	   System.out.println("Width= " +b.width);
	   System.out.println("Height= " +b.height);
	   System.out.println("Depth= " +b.depth);
	   int v=b.volume();
	   System.out.println("Volume= "+v);
	  }
	}


