package corejavaexercises;

class   Lesson4C
{
public static void main(String as[])
{
   int a,b,sum;
    a=Integer.parseInt(as[0]);
    b=Integer.parseInt(as[1]);
    sum=a+b;
   System.out.println("Sum:"+sum);
}
}

