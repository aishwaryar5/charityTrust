package corejavaexercises;

public class Student {

int rno=101,marks=97;
String name="Tesla";
void print()
{
System.out.println("Roll no= "+rno+" Marks= "+marks+" Name= "+name);
}
}
class StudInfo
{
public static void main(String arg[])
{
Student s=new Student();
s.print();
}
}

