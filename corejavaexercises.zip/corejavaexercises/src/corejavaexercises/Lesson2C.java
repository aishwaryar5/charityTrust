package corejavaexercises;

public class Lesson2C {
	
	public static void main(String s[])
	{
	    float a,b;
	   a=Float.parseFloat(s[0]);
	b=Float.parseFloat(s[1]);
	a=a+b;
	System.out.println(a);
	}
	}



