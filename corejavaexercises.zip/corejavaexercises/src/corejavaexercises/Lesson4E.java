package corejavaexercises;
import java.util.*;
public class Lesson4E {

public static void main(String as[])
{
   Scanner s=new Scanner(System.in);
   
     System.out.println("Enter 2 elements to compare:");
   int a=s.nextInt();
int b=s.nextInt();
s.close();
  if(a==b)
   System.out.println(a+" is equal to "+b);
  if(a<b)
   System.out.println(a+" is lesser than "+b);
  if(a>b)
  System.out.println(a+" is greater than "+b);
  if(a<=b)
  System.out.println(a+" is lesser than or equal to "+b);
  if(a>=b)
System.out.println(a+" is greater than or equal to "+b);
  if(a!=b)
System.out.println(a+" is not equal to "+b);

}
}

