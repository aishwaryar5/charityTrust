package corejavaexercises;

public class Lesson2F {
	
	
	public static void main(String s[])
	{
	int a;
	a=Integer.parseInt(s[0]);
	if(a%2==0)
	{
	System.out.println("Even");
	}
	else
	{
	System.out.println("Odd");
	}
	}
	}


