
import java.util.*;
public class Count{
public static void main(String[] args){
Scanner scan=new Scanner(System.in);
String str=scan.next();

    int count = 0;
    for(int i = 0; i < str.length() - 1; i++) {
        if(str.substring(i, i + 2).equals("xx"))
            count++;
    }
    System.out.println(count);
    scan.close();
}
}
