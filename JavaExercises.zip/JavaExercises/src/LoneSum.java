import java.util.*;
public class LoneSum{
public static void main(String arg[]){
Scanner scan=new Scanner(System.in);
int a=scan.nextInt();
int b=scan.nextInt();
int c=scan.nextInt();
scan.close();
if(a == b)
  {   
    if(a == c)
      System.out.println(0);
    System.out.println(c);
}
  if(a == c)
	  System.out.println(b);
  if(b == c)
	  System.out.println(a);
  else
  System.out.println(a+b+c);
}
}

