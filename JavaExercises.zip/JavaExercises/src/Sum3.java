import java.util.*;
	public class Sum3{
public static void main(String arg[]){
	int result=0;
	Scanner s= new Scanner(System.in);
	int[] arr=new int[4];
	for(int i=0;i<3;i++)
	{
	arr[i]=s.nextInt();
	}
	result=arraysum(arr);
    s.close();
	System.out.println("sum:"+result); 
}
	public static int arraysum(int[] nums) {
	    return nums[0]+nums[1]+nums[2];
	}
	}