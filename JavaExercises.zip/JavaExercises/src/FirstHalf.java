import java.util.*;
public class FirstHalf
{
public static void main(String args[])
{

Scanner in=new Scanner(System.in);
String str=in.next();
System.out.println(str.substring(0,str.length()/2));
in.close();
}
}