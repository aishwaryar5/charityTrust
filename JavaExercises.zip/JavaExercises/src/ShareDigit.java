import java.util.*;
class ShareDigit
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
sc.close();
boolean result;
result= shareDigit(a,b);
System.out.println(result);
}

public static boolean shareDigit(int a, int b) {
    return (a % 10 == b % 10 || a / 10 == b / 10 || 
            a % 10 == b / 10 || b % 10 == a / 10);
}
}