import java.util.*;
 
class Lapindrome
{
	public static void main (String[] args) throws java.lang.Exception
    {
           
           Scanner sc = new Scanner(System.in);
           int t;
           String str = "";
           System.out.println("Enter the number of testcases");
           t = sc.nextInt();
           for(int i=0;i<t;i++)
           {
                  str = sc.next();
                  int n = str.length();
                  
                  if(n % 2 == 0)
                  {
                        String s1 = str.substring(0, n/2);
                        String s2 = str.substring(n/2);
                        char a[] = s1.toCharArray();
                        char b[] = s2.toCharArray();
                        Arrays.sort(a);
                        Arrays.sort(b);
                        if(Arrays.equals(a, b))
                               System.out.println("YES");
                        else
                               System.out.println("NO");
                               
                  }
                  else
                  {
                        String s1 = str.substring(0, (n/2)+1);
                        String s2 = str.substring(n/2);
                        char a[] = s1.toCharArray();
                        char b[] = s2.toCharArray();
                        Arrays.sort(a);
                        Arrays.sort(b);
                        if(Arrays.equals(a, b))
                               System.out.println("YES");
                        else
                               System.out.println("NO");
                  }
           }
           sc.close();
    }
}


