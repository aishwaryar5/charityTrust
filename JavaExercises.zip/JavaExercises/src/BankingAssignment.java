



class bankAcc
{
       int accno;
       String  name="";
       String address="";
       double  balance;
       

       void display()
       {
              System.out.println("Account Number="+accno);
              System.out.println("Name="+name);
              System.out.println("Address="+address);
              System.out.println("Balance="+balance);
       }
       void withdraw(long amount)
       {
              balance-=0.25;
              balance=balance-amount;
              
       }
       void deposit(long amount)
       {
              balance=balance+amount;
       }
       void  pass(int i, String string, String string2, double d) {
              accno=i;
              name=string;
              address=string2;
              balance=d;
       }
       
}
class DepositACC extends bankAcc
{
       
       
void withdraw(long amount)
{
       if(balance>amount)
       {
              super.withdraw(amount);
       }
       else
       {
              System.out.println("Insufficient Balance"+balance);
       }
}
       
       
}
class CurrentAcc extends DepositACC
{
       long limit;
       int trans=0,interest;
       DepositACC da=new DepositACC();
       
       public void CurrentAcc(long limit,int interest) {
       this.limit=limit;
       this.interest=interest;
       }
       
       void withdraw(long amount)
       {
              if(amount<=limit)
              {
                     trans++;
                     super.withdraw(amount);
              }
              else
              {
                     System.out.println("Withdrawn Amount exceeds the limit");
              }
       }
       void deposit(long amount)
       {
              super.deposit(amount);
       }
       
       void display()
       {
              super.display();
       }

       
}
public class BankingAssignment {
       public static void main(String Arg[])
       {
CurrentAcc Ca=new CurrentAcc();
bankAcc ba=new bankAcc();
Ca.pass(12345,"New Customer","Chennai",100000.0);
Ca.CurrentAcc(50000,4);
Ca.withdraw(300);
Ca.deposit(4500);
Ca.display();
       }
}
