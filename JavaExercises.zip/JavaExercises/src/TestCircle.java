import java.util.*;
interface GeometricObject
{
void getParameter();
void getArea();
}
class Circle implements GeometricObject
{
int rad;
float area;
Scanner sc=new Scanner(System.in);
public void getParameter()
{
System.out.println("Enter Radius");
rad=sc.nextInt();
}
public void getArea()
{
area=(3.14f*rad*rad);
System.out.println("Area= "+area);
}
}
class TestCircle
{
public static void main(String arg[])
{
Circle c=new Circle();
c.getParameter();
c.getArea();
}
}


