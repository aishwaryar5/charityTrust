import java.util.*;
class TeenSum
{
public static void main(String args[])
{
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
sc.close();
int result;
result=teenSum(a,b);
System.out.println(result);
}
public static int teenSum(int a, int b) {
    return (a >= 13 && a <= 19 || b >= 13 && b <= 19) ? 19 : a + b;
}
}
