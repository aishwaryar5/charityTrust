import java.util.*;
class MyCalculator{
	public static void main(String ars[]){
			int n,p;
			Scanner scan=new Scanner(System.in);
			System.out.println("Enter two numbers");
			n=scan.nextInt();
			p=scan.nextInt();
			scan.close();
			try{
			int result=power(n,p);
			System.out.println(result);
			}
			catch(IllegalArgumentException e){
				System.out.println(e);
			}
			
	
}
	 static int power(int n,int p)throws IllegalArgumentException {
		if(n<0 || p< 0)
		{
			throw new IllegalArgumentException("n and p should be non negative");
		}
		else 
			return (n*p);
}
}



