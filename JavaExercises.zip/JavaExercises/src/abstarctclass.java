import java.util.Scanner;

abstract class Arithmetic
{
       abstract int add(int a,int b);
}
class adder extends Arithmetic
{

       @Override
       int add(int a,int b) {
              
              return a+b;
       }
       
}
public class abstarctclass {

public static void main(String arg[])
{
       Scanner sc=new Scanner(System.in);
       Arithmetic ar=new adder();
       System.out.println("Enter the two number to Add:");
       int a=sc.nextInt(),b=sc.nextInt();
       int sum=ar.add(a,b);
       sc.close();
       System.out.println("Sum of two number using Abstract method="+sum);
}
}