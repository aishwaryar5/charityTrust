import java.util.*;
	public class Solution{
public static void main(String arg[]){
	int count = 0;
	Scanner s= new Scanner(System.in);
	System.out.println("enter the length of the array");
	int len=s.nextInt();
	int[] arr=new int[len];
	System.out.println("enter the elements of  the array");
	for(int i=0;i<len;i++)
	{
	arr[i]=s.nextInt();
	}
	for(int i=0;i<len;i++){
	  if(arr[i] == 9)
	            count++;
	}
	    
	    s.close();                
	    System.out.println(count);
	}
	}
