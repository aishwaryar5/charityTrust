import java.util.*;
class ExceptionTwo
{
 public static void main(String s[])
 {
  try
  {
   int a[]={10,20};
   Scanner sc=new Scanner(System.in);
   System.out.print("Enter the value to divide");
   int n=sc.nextInt();
   a[0]=a[1]/n;
  }
  catch(ArithmeticException e)
  {
   System.out.println("ArithmeticException Caught:"+e);
  }
  try
  {
   int a[]={1,2};
   a[1]=a[5];
  }
  catch(ArrayIndexOutOfBoundsException e)
  {
   System.out.println("ArrayIndexOutOfBound Caught:"+e);
  }
  try
  {
   String str=null;
   if(str.equals("asdf"))
    System.out.println("NO Null");
  }
  catch(NullPointerException e)
  {
   System.out.print("NullPointerException Caught:"+e);
  }
 } 
}  

