import java.util.*;
class InsufficientBalanceException extends Exception
{
 InsufficientBalanceException(String s)
 {
  super(s);
 }
}
class WithDraw
{
 double bal;
 void getBal()
 {
 Scanner sc=new Scanner(System.in);
 System.out.println("Enter balance");
 bal=sc.nextDouble();
 }
 void withDrawMoney(double atwd)throws InsufficientBalanceException
 {
  if(bal<=atwd)
  {
   throw new InsufficientBalanceException("You Cannot WithDraw Amount ur balance is less than the amount u need!!!");
  }
  else
  {
   System.out.println(" "+(bal-atwd));
  }

 }
}
class ExceptionFirst
{
 public static void main(String s[])
 {
  double amt;
  Scanner sc=new Scanner(System.in);
  
  WithDraw wd=new WithDraw();
  wd.getBal();
  System.out.println("Enter Withdraw");
  amt=sc.nextDouble();
  sc.close();
  try 
  {
   wd.withDrawMoney(amt);
  }
  catch(Exception m)
  {
   System.out.println(m);
  }
 }
}


