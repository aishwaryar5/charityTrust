import java.util.Scanner;


public class factorial2 {
 public static void main(String args[]){
	 int i=1,fact=1; 
	 Scanner s =  new Scanner(System.in);
	 int n = s.nextInt();
	  while(i<n){
		 fact= fact*i;
		 i++;
	 }
		 System.out.println(fact);
		 s.close();
	 }
	 
 }

