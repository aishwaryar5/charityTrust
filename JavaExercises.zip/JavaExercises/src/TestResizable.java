import java.util.*;
interface GeometricObject1
{
void getParameter();
void getArea();
}
interface Resizable
{
void resize(int perc);
}
class Circle1 implements GeometricObject1
{
int rad;
float area;
Scanner sc=new Scanner(System.in);
public void getParameter()
{
System.out.println("Enter Radius");
rad=sc.nextInt();
}
public void getArea()
{
area=(3.14f*rad*rad);
System.out.println("Area= "+area);
}
}
class ResizableCircle extends Circle1 implements Resizable
{
public void resize(int perc)
{
rad+=(rad*perc)/100;
System.out.println("Increased Radius= "+rad);
}
}
class TestResizable
{
public static void main(String arg[])
{
int per;
ResizableCircle r=new ResizableCircle();
r.getParameter();
r.getArea();
System.out.println("Enter percent");
Scanner sc=new Scanner(System.in);
per=sc.nextInt();
r.resize(per);
r.getArea();
sc.close();
}
}