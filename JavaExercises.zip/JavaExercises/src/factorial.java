import java.util.Scanner;

class factorial{  
 public static void main(String args[]){  
  int i,fact=1;  
  Scanner s =  new Scanner(System.in);
	 int n = s.nextInt();//It is the number to calculate factorial    
  for(i=1;i<=n;i++){    
      fact=fact*i;    
  }    
  System.out.println("Factorial of "+n+" is: "+fact); 
  s.close();
 }  
}  
