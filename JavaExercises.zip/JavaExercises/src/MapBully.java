import java.util.*;
import java.io.*;
class MapBully
{	
public static void main(String args[])
{
Scanner s=new Scanner(System.in);
System.out.println("enter size");
int n=s.nextInt();
s.nextLine();
HashMap<String,String>  map=new HashMap<String,String>();

for(int i=0;i<n;i++)
{
System.out.println("Enter key");
String z=s.next();
System.out.println("Enter value");
String z1=s.next();
map.put(z,z1);
}
map=mapBully(map);
System.out.println(map);
}
public static HashMap<String, String> mapBully(HashMap<String, String> map) {
  if(map.containsKey("a"))
  {
    map.put("b",map.get("a"));
    map.put("a","");
  }return map;
}
}
