import java.util.*;



public class CowsBulls {
       public static void main(String args[])
       {
              Scanner scan = new Scanner(System.in);
              String strtothink = scan.next();
              String strtofind = scan.next();
              scan.close();
                  int bulls = 0;
                  int[] nums1 = new int[10];
                  int[] nums2 = new int[10];
                  for(int i = 0; i < strtothink.length(); i++){
                      char t = strtothink.charAt(i);
                      char f = strtofind.charAt(i);
                      if(t == f){
                          bulls++;
                      }
                      else{
                          nums1[t - '0']++;
                          nums2[f - '0']++;
                      }
                  }
                  int cows = 0;
                  for(int i = 0; i < 10; i++){
                      cows += Math.min(nums1[i], nums2[i]);
                  }
                  System.out.println(" Bulls "+bulls+" cows "+cows);
                
              }
}

